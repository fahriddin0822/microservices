import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductModule } from './product/product.module';
import { Product } from './product/entities/product.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: "mysql",
      host: "localhost",
      port: 3306,
      password: "3306",
      username: "root",
      database: "backend1",
      entities: [Product],
      synchronize: true
    }),
    ProductModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule { }
