import { Inject, Injectable } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Product } from './entities/product.entity';
import { Repository } from 'typeorm';
import { ClientProxy } from '@nestjs/microservices';

@Injectable()
export class ProductService {
  constructor(
    @InjectRepository(Product) private readonly productRepo: Repository<Product>,
    @Inject('PRODUCT_SERVICE') private readonly clientService: ClientProxy,
  ) { }

  async create(createProductDto: CreateProductDto) {
    const newProduct = await this.productRepo.save(createProductDto);
    return newProduct;  
  }

  findAll() {
    return this.productRepo.find();
  }

  findOne(id: number) {
    return this.productRepo.findOneBy({ id });
  }

  async update(id: number, updateProductDto: UpdateProductDto) {
    await this.productRepo.update({ id }, updateProductDto);
    const updatedProduct = await this.productRepo.findOneBy({ id });
    this.clientService.emit("product_updated", updatedProduct);
    return updatedProduct;
  }

  async remove(id: number) {
    await this.productRepo.delete(id);
    this.clientService.emit("product_deleted", id);
    return `Product with id ${id} has been deleted.`;
  }
}
