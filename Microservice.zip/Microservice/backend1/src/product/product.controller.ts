import { Controller, Get, Post, Body, Patch, Param, Delete, Inject, BadRequestException } from '@nestjs/common';
import { ProductService } from './product.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ClientProxy } from '@nestjs/microservices';

@Controller('product')
export class ProductController {
  constructor(
    private readonly productService: ProductService,
    @Inject("PRODUCT_SERVICE") private readonly clientDervice: ClientProxy
  ) { }

  @Post()
  async create(@Body() createProductDto: CreateProductDto) {
    const newProduct = await this.productService.create(createProductDto);
    this.clientDervice.emit("product_created", newProduct);
    return newProduct;
  }

  @Post(":id/like")
  async likeBoss( @Param("id") id:string ) {
    const product =  await this.productService.findOne(+id);
    if(!product){
      throw new BadRequestException('Product not found');
    }
    product.likes+=1;
    await this.productService.update(+id, product);
    return product;
  }

  @Get()
  findAll() {
    this.clientDervice.emit("hello", "Hello from another server").subscribe((data) => {
      console.log(data);
    });
    this.clientDervice.send("salom", "Salom from another server").subscribe((data) => {
      console.log(data);
    });
    return this.productService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.productService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateProductDto: UpdateProductDto) {
    return this.productService.update(+id, updateProductDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.productService.remove(+id);
  }
}
