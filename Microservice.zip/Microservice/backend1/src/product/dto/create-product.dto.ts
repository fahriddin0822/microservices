export class CreateProductDto {
    name: string;
    price: number;
    image: string;
}
