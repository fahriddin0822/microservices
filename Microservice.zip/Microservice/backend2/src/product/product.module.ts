import { Module } from '@nestjs/common';
import { ProductService } from './product.service';
import { ProductController } from './product.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Product, ProductSchema } from './schemas/product.schema';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { ProductMicroserviceController } from './product_microservice.controller';

@Module({
  imports: [
    // Correct usage of MongooseModule.forFeature with schema and name
    MongooseModule.forFeature([{ name: Product.name, schema: ProductSchema }]),

    // ClientsModule.register([
    //   {
    //     name: 'PRODUCT_SERVICE',
    //     transport: Transport.RMQ,
    //     options: {
    //       urls: ['amqps://osyffspv:AOrlMFURTgGFFvXsXt8npkwvslr3uwyP@whale.rmq.cloudamqp.com/osyffspv'],
    //       queue: 'main_products_queue',
    //       queueOptions: {
    //         durable: false
    //       },
    //     },
    //   },
    // ]),
  ],
  controllers: [ProductController, ProductMicroserviceController],
  providers: [ProductService],
  exports: [ProductService],
})
export class ProductModule { }
