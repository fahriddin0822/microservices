import { Injectable } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Product, ProductDocument } from './schemas/product.schema';
import { Model } from 'mongoose';
import { EventPattern } from '@nestjs/microservices';

@Injectable()
export class ProductService {
  constructor(@InjectModel(Product.name) private productModel: Model<ProductDocument>) { }

  async create(createProductDto: CreateProductDto): Promise<Product> {
    return this.productModel.create(createProductDto);
  }

  async findAll(): Promise<Product[]> {
    return this.productModel.find().exec();
  }

  async findOne(id: number): Promise<Product> {
    return this.productModel.findOne({ id });
  }

  async update(id: number, updateProductDto: UpdateProductDto): Promise<Product> {
    return this.productModel.findOneAndUpdate({ id }, updateProductDto, { new: true });
  }

  async remove(id: number): Promise<Product> {
    return this.productModel.findOneAndDelete({ id });
  }
}
