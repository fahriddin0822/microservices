import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ProductService } from './product.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { EventPattern, MessagePattern, Payload } from '@nestjs/microservices';

@Controller('product')
export class ProductMicroserviceController {
  constructor(private readonly productService: ProductService) {}

  // Microservice event listener
  @EventPattern('hello')
  async handleHelloEvent(@Payload() data: string) {
    console.log('Received event:', data);
    return "Hello recieved."
  }

  @MessagePattern('salom')
  async handleSalomEvent(@Payload() data: string) {
    console.log('Received event:', data);
    return "Salom recieved."
  }

  @EventPattern("product_created")
  create(@Body() createProductDto: CreateProductDto) {
    return this.productService.create(createProductDto);
  }
  
  @EventPattern('product_updated')
  update(@Payload() updateProductDto: UpdateProductDto) {
    return this.productService.update(updateProductDto.id, updateProductDto);
  }

  @EventPattern('product_deleted')
  remove(@Payload() id: number) {
    return this.productService.remove(id);
  }

  // @Get()
  // findAll() {
  //   return this.productService.findAll();
  // }

  // @Get(':id')
  // findOne(@Param('id') id: number) {
  //   return this.productService.findOne(id);
  // }
}
