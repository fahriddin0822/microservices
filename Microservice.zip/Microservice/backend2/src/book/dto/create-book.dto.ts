export class CreateBookDto {}
